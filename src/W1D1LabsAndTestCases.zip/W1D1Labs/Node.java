package W1D1Labs;

class Node {
    int val;
    Node next;

    Node(int val1) {
    	val = val1;
        next = null;
    }
}